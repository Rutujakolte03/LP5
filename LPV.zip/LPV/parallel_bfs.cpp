// File: parallel_bfs.cpp
#include <iostream>
#include <vector>
#include <queue>
#include <omp.h>

using namespace std;

void parallelBFS(vector<vector<int>>& graph, int start) {
    int n = graph.size();
    vector<bool> visited(n, false);
    queue<int> q;

    visited[start] = true;
    q.push(start);

    cout << "Parallel BFS Traversal: ";

    while (!q.empty()) {
        int levelSize = q.size();
        vector<int> currentLevel;

        // Collect nodes at current level
        for (int i = 0; i < levelSize; ++i) {
            int node = q.front();
            q.pop();
            currentLevel.push_back(node);
            cout << node << " ";
        }

        // Visit neighbors in parallel
        #pragma omp parallel for
        for (int i = 0; i < currentLevel.size(); ++i) {
            int u = currentLevel[i];
            for (int v : graph[u]) {
                if (!visited[v]) {
                    #pragma omp critical
                    {
                        if (!visited[v]) {
                            visited[v] = true;
                            q.push(v);
                        }
                    }
                }
            }
        }
    }

    cout << endl;
}

int main() {
    // Undirected graph represented as an adjacency list
    vector<vector<int>> graph = {
        {1, 2},   // Node 0
        {0, 3},   // Node 1
        {0, 4},   // Node 2
        {1},      // Node 3
        {2}       // Node 4
    };

    int startNode = 0;
    cout << "Starting Parallel BFS from node " << startNode << ":\n";
    parallelBFS(graph, startNode);

    return 0;
}
